package com.example.donna.newelection;

/**
 * Created by tolitz on 2/9/2016.
 */
public class CandidateConfig {

    //JSON URL
    public static final String DATA_URL = "http://192.168.1.141/mobile/getCandidate.php";

    //Tags used in the JSON String
    public static final String TAG_NAME = "name";
    public static final String TAG_CODE = "candcode";
    //JSON array name
    public static final String JSON_ARRAY = "result";
}
