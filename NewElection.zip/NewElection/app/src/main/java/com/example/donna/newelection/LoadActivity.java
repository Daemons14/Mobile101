package com.example.donna.newelection;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

public class LoadActivity extends AppCompatActivity {
    ProgressBar pbbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load);
        //PROGRESS BAR

        //Loading Page before login page
        pbbar = (ProgressBar) findViewById(R.id.progressBar);
        pbbar.setVisibility(View.VISIBLE);
        Thread timerThread = new Thread(){
            public void run(){
                try{
                    sleep(3000); //Timeout of 3000  = 3 secs
                }catch(InterruptedException e){
                    e.printStackTrace();
                }finally{
                    Intent intent = new Intent(LoadActivity.this,MainActivity.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.right_out, R.anim.top_out); //Page Transition
                }
            }
        };
        timerThread.start();
    }
    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        finish();
    }
}
