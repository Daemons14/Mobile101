package com.example.donna.newelection;

/**
 * Created by Donna on 1/22/2016.
 */
import java.io.Serializable;

public class Student implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private String name;

    private String emailId;

    private boolean isSelected;

    public Student() {

    }

    public Student(String name, String emailId) {

        this.name = name;


    }

    public Student(String name, String emailId, boolean isSelected) {

        this.name = name;

        this.isSelected = isSelected;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }

}
