package com.example.donna.newelection;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TabHost;
import com.google.android.gms.common.api.GoogleApiClient;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Vote extends AppCompatActivity {
    private Button btnsubmit;
    TabHost tabHost;
    Context context;
    private JSONArray result;
    private ArrayList<String> candidates;
    ProgressBar pbbar;
    
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vote);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //Tabhost
        pbbar = (ProgressBar)findViewById(R.id.pbar2);
        pbbar.setVisibility(View.GONE);
        btnsubmit = (Button) findViewById(R.id.vote);
        getData();
    }
    private void getData(){
        pbbar.setVisibility(View.VISIBLE);
        //Creating a string request
        StringRequest stringRequest = new StringRequest(CandidateConfig.DATA_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject j = null;
                        try {
                            //Parsing the fetched Json String to JSON Object
                            j = new JSONObject(response);

                            //Storing the Array of JSON String to our JSON Array
                            result = j.getJSONArray(CandidateConfig.JSON_ARRAY);

                            getStudents(result);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        //Creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //Adding request to the queue
        requestQueue.add(stringRequest);
    }
    private void getStudents(JSONArray j){
        //Traversing through all the items in the json array
        for(int i=0;i<j.length();i++){
            try {
                //Getting json object
                JSONObject json = j.getJSONObject(i);

                //Adding the name of the candidate to array list
                candidates.add(json.getString(CandidateConfig.TAG_NAME));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        final Spinner spinner = (Spinner) findViewById(R.id.spinner1);
        final Spinner spinner1 = (Spinner) findViewById(R.id.spinner2);
        //Setting adapter to show the items in the spinner
        spinner.setAdapter(new ArrayAdapter<String>(Vote.this, android.R.layout.simple_spinner_dropdown_item, candidates));
        spinner1.setAdapter(new ArrayAdapter<String>(Vote.this, android.R.layout.simple_spinner_dropdown_item, candidates));
        pbbar.setVisibility(View.GONE);
    }
    //Method to get candidate name of a particular position
    private String getName(int position){
        String name="";
        try {
            //Getting object of given index
            JSONObject json = result.getJSONObject(position);

            //Fetching name from that object
            name = json.getString(CandidateConfig.TAG_NAME);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        //Returning the name
        return name;
    }

}






